# React 18

## 资源

1.[React18 发布文档](https://reactjs.org/blog/2022/03/29/react-v18.html)

## 开始学习

![image-20220330122647056](/Users/gaoshaoyun/Library/Application Support/typora-user-images/image-20220330122647056.png)
