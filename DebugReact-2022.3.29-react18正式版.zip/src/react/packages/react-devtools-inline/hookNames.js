module.exports = require('./dist/hookNames');
