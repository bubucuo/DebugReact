This directory contains code shared between several DevTools packages:
* /packages/react-devtools-core
* /packages/react-devtools-extensions
* /packages/react-devtools-inline

It is not published or released anywhere directly.